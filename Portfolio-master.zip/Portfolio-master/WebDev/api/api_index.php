<?php
require_once ("master_page.php"); // Includes the header and footer
require_once ("scripts.php");
require_once ("store.php");
require_once ("load.php");
require_once ("review.php");
?>